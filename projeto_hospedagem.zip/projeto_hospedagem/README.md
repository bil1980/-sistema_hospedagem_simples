# Sistema de Hospedagem

Projeto avaliativo de Banco de Dados.

## Tecnologias

- Python
- Tkinter
- PostgreSQL
- psycopg2

## Recursos de Banco de Dados

### View
`vw_reservas`

Utilizada na tela "Relatório de Reservas" para apresentar os dados das reservas junto com o nome do hóspede.

### Function
`calcular_valor_reserva`

Recebe a quantidade de dias e o valor da diária e retorna o valor total da hospedagem.

### Procedure
`criar_reserva`

Recebe os dados da reserva, valida o hóspede e as datas e insere uma nova reserva com status ATIVA.

## Como executar

1. Crie o banco PostgreSQL chamado `sistema_hospedagem`.
2. Execute o arquivo `database/estrutura.sql`.
3. Instale o psycopg2:

```bash
pip install psycopg2-binary
```

4. Abra `src/sistema.py`.
5. Confira `DB_CONFIG` e coloque a senha do seu PostgreSQL.
6. Execute:

```bash
python src/sistema.py
```
