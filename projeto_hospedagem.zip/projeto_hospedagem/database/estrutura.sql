-- 1) TABELAS
CREATE TABLE IF NOT EXISTS hospede (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telefone VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS reserva (
    id SERIAL PRIMARY KEY,
    id_hospede INTEGER NOT NULL REFERENCES hospede(id),
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    valor_diaria NUMERIC(10,2) NOT NULL,
    status VARCHAR(20) NOT NULL
);

-- 2) DADOS DE TESTE
INSERT INTO hospede (nome, email, telefone)
SELECT 'João Silva', 'joao@email.com', '86999999999'
WHERE NOT EXISTS (SELECT 1 FROM hospede WHERE email = 'joao@email.com');

INSERT INTO hospede (nome, email, telefone)
SELECT 'Maria Santos', 'maria@email.com', '86988888888'
WHERE NOT EXISTS (SELECT 1 FROM hospede WHERE email = 'maria@email.com');

-- 3) FUNCTION
CREATE OR REPLACE FUNCTION calcular_valor_reserva(
    p_dias INTEGER,
    p_valor_diaria NUMERIC
)
RETURNS NUMERIC
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_dias <= 0 THEN
        RAISE EXCEPTION 'A quantidade de dias deve ser maior que zero';
    END IF;

    IF p_valor_diaria < 0 THEN
        RAISE EXCEPTION 'O valor da diária não pode ser negativo';
    END IF;

    RETURN p_dias * p_valor_diaria;
END;
$$;

-- 4) PROCEDURE
CREATE OR REPLACE PROCEDURE criar_reserva(
    p_id_hospede INTEGER,
    p_check_in DATE,
    p_check_out DATE,
    p_valor_diaria NUMERIC
)
LANGUAGE plpgsql
AS $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM hospede WHERE id = p_id_hospede
    ) THEN
        RAISE EXCEPTION 'Hóspede não encontrado';
    END IF;

    IF p_check_out <= p_check_in THEN
        RAISE EXCEPTION 'A data de saída deve ser posterior à entrada';
    END IF;

    IF p_valor_diaria <= 0 THEN
        RAISE EXCEPTION 'O valor da diária deve ser maior que zero';
    END IF;

    INSERT INTO reserva (
        id_hospede, check_in, check_out, valor_diaria, status
    )
    VALUES (
        p_id_hospede, p_check_in, p_check_out, p_valor_diaria, 'ATIVA'
    );
END;
$$;

-- 5) VIEW
CREATE OR REPLACE VIEW vw_reservas AS
SELECT
    r.id AS id_reserva,
    h.nome AS hospede,
    r.check_in,
    r.check_out,
    r.valor_diaria,
    r.status
FROM reserva r
INNER JOIN hospede h ON h.id = r.id_hospede;
