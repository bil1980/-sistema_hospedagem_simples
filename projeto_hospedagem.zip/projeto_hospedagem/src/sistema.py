import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import psycopg2

# ==========================================================
# CONFIGURAÇÃO DO BANCO
# ALTERE SOMENTE ESTES DADOS SE NECESSÁRIO
# ==========================================================
DB_CONFIG = {
    "host": "localhost",
    "database": "sistema_hospedagem",
    "user": "postgres",
    "password": "1234",
    "port": "5432"
}


def conectar():
    return psycopg2.connect(**DB_CONFIG)


# ==========================================================
# JANELA PRINCIPAL
# ==========================================================
class SistemaHospedagem:
    def __init__(self, root):
        self.root = root
        self.root.title("Sistema de Hospedagem")
        self.root.geometry("850x600")
        self.root.resizable(False, False)

        self.criar_interface()

    def limpar_tela(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def criar_interface(self):
        self.limpar_tela()

        titulo = tk.Label(
            self.root,
            text="SISTEMA DE HOSPEDAGEM",
            font=("Arial", 22, "bold")
        )
        titulo.pack(pady=30)

        subtitulo = tk.Label(
            self.root,
            text="Gerenciamento de hóspedes e reservas",
            font=("Arial", 12)
        )
        subtitulo.pack(pady=5)

        frame = tk.Frame(self.root)
        frame.pack(pady=35)

        tk.Button(
            frame, text="Cadastrar Hóspede",
            width=25, height=2,
            command=self.tela_hospede
        ).grid(row=0, column=0, padx=10, pady=10)

        tk.Button(
            frame, text="Nova Reserva",
            width=25, height=2,
            command=self.tela_reserva
        ).grid(row=0, column=1, padx=10, pady=10)

        tk.Button(
            frame, text="Calcular Valor",
            width=25, height=2,
            command=self.tela_calculo
        ).grid(row=1, column=0, padx=10, pady=10)

        tk.Button(
            frame, text="Relatório de Reservas",
            width=25, height=2,
            command=self.tela_relatorio
        ).grid(row=1, column=1, padx=10, pady=10)

        tk.Button(
            self.root, text="Sair",
            width=20, command=self.root.destroy
        ).pack(pady=20)

    # ======================================================
    # CADASTRO DE HÓSPEDE
    # ======================================================
    def tela_hospede(self):
        self.limpar_tela()

        tk.Label(
            self.root, text="CADASTRAR HÓSPEDE",
            font=("Arial", 20, "bold")
        ).pack(pady=25)

        frame = tk.Frame(self.root)
        frame.pack(pady=10)

        tk.Label(frame, text="Nome:").grid(row=0, column=0, sticky="e", padx=10, pady=10)
        nome = tk.Entry(frame, width=35)
        nome.grid(row=0, column=1)

        tk.Label(frame, text="E-mail:").grid(row=1, column=0, sticky="e", padx=10, pady=10)
        email = tk.Entry(frame, width=35)
        email.grid(row=1, column=1)

        tk.Label(frame, text="Telefone:").grid(row=2, column=0, sticky="e", padx=10, pady=10)
        telefone = tk.Entry(frame, width=35)
        telefone.grid(row=2, column=1)

        def salvar():
            if not nome.get().strip():
                messagebox.showwarning("Atenção", "Informe o nome.")
                return

            try:
                conn = conectar()
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO hospede (nome, email, telefone) VALUES (%s, %s, %s)",
                    (nome.get(), email.get(), telefone.get())
                )
                conn.commit()
                cur.close()
                conn.close()

                messagebox.showinfo("Sucesso", "Hóspede cadastrado!")
                nome.delete(0, tk.END)
                email.delete(0, tk.END)
                telefone.delete(0, tk.END)

            except Exception as e:
                messagebox.showerror("Erro", str(e))

        tk.Button(
            self.root, text="Salvar", width=20, command=salvar
        ).pack(pady=15)

        tk.Button(
            self.root, text="Voltar",
            width=20, command=self.criar_interface
        ).pack()

    # ======================================================
    # NOVA RESERVA - CHAMA A PROCEDURE
    # ======================================================
    def tela_reserva(self):
        self.limpar_tela()

        tk.Label(
            self.root, text="NOVA RESERVA",
            font=("Arial", 20, "bold")
        ).pack(pady=20)

        frame = tk.Frame(self.root)
        frame.pack(pady=5)

        tk.Label(frame, text="ID do hóspede:").grid(row=0, column=0, sticky="e", padx=10, pady=8)
        id_hospede = tk.Entry(frame, width=30)
        id_hospede.grid(row=0, column=1)

        tk.Label(frame, text="Check-in (AAAA-MM-DD):").grid(row=1, column=0, sticky="e", padx=10, pady=8)
        check_in = tk.Entry(frame, width=30)
        check_in.grid(row=1, column=1)

        tk.Label(frame, text="Check-out (AAAA-MM-DD):").grid(row=2, column=0, sticky="e", padx=10, pady=8)
        check_out = tk.Entry(frame, width=30)
        check_out.grid(row=2, column=1)

        tk.Label(frame, text="Valor da diária:").grid(row=3, column=0, sticky="e", padx=10, pady=8)
        valor = tk.Entry(frame, width=30)
        valor.grid(row=3, column=1)

        def criar():
            try:
                hid = int(id_hospede.get())
                entrada = datetime.strptime(check_in.get(), "%Y-%m-%d").date()
                saida = datetime.strptime(check_out.get(), "%Y-%m-%d").date()
                diaria = float(valor.get().replace(",", "."))

                conn = conectar()
                cur = conn.cursor()

                # APLICAÇÃO -> PROCEDURE -> BANCO
                cur.execute(
                    "CALL criar_reserva(%s, %s, %s, %s)",
                    (hid, entrada, saida, diaria)
                )

                conn.commit()
                cur.close()
                conn.close()

                messagebox.showinfo(
                    "Sucesso",
                    "Reserva criada com sucesso!\n\nA Procedure criar_reserva foi executada."
                )

                id_hospede.delete(0, tk.END)
                check_in.delete(0, tk.END)
                check_out.delete(0, tk.END)
                valor.delete(0, tk.END)

            except Exception as e:
                messagebox.showerror("Erro", str(e))

        tk.Button(
            self.root, text="Criar Reserva",
            width=25, command=criar
        ).pack(pady=15)

        tk.Button(
            self.root, text="Voltar",
            width=20, command=self.criar_interface
        ).pack()

    # ======================================================
    # CALCULAR VALOR - CHAMA A FUNCTION
    # ======================================================
    def tela_calculo(self):
        self.limpar_tela()

        tk.Label(
            self.root, text="CALCULAR VALOR DA RESERVA",
            font=("Arial", 20, "bold")
        ).pack(pady=25)

        frame = tk.Frame(self.root)
        frame.pack(pady=10)

        tk.Label(frame, text="Quantidade de dias:").grid(row=0, column=0, padx=10, pady=10)
        dias = tk.Entry(frame, width=25)
        dias.grid(row=0, column=1)

        tk.Label(frame, text="Valor da diária:").grid(row=1, column=0, padx=10, pady=10)
        diaria = tk.Entry(frame, width=25)
        diaria.grid(row=1, column=1)

        resultado = tk.Label(
            self.root,
            text="Valor total: R$ 0,00",
            font=("Arial", 16, "bold")
        )
        resultado.pack(pady=20)

        def calcular():
            try:
                qtd_dias = int(dias.get())
                valor_diaria = float(diaria.get().replace(",", "."))

                conn = conectar()
                cur = conn.cursor()

                # APLICAÇÃO -> FUNCTION -> BANCO
                cur.execute(
                    "SELECT calcular_valor_reserva(%s, %s)",
                    (qtd_dias, valor_diaria)
                )

                total = cur.fetchone()[0]

                cur.close()
                conn.close()

                resultado.config(
                    text=f"Valor total: R$ {float(total):.2f}".replace(".", ",")
                )

            except Exception as e:
                messagebox.showerror("Erro", str(e))

        tk.Button(
            self.root, text="Calcular",
            width=25, command=calcular
        ).pack(pady=10)

        tk.Button(
            self.root, text="Voltar",
            width=20, command=self.criar_interface
        ).pack()

    # ======================================================
    # RELATÓRIO - USA A VIEW
    # ======================================================
    def tela_relatorio(self):
        self.limpar_tela()

        tk.Label(
            self.root, text="RELATÓRIO DE RESERVAS",
            font=("Arial", 20, "bold")
        ).pack(pady=20)

        colunas = (
            "id", "hospede", "check_in",
            "check_out", "diaria", "status"
        )

        tabela = ttk.Treeview(
            self.root,
            columns=colunas,
            show="headings",
            height=15
        )

        titulos = {
            "id": "ID",
            "hospede": "Hóspede",
            "check_in": "Check-in",
            "check_out": "Check-out",
            "diaria": "Diária",
            "status": "Status"
        }

        for coluna in colunas:
            tabela.heading(coluna, text=titulos[coluna])
            tabela.column(coluna, width=120)

        tabela.pack(padx=20, pady=10)

        def carregar():
            try:
                conn = conectar()
                cur = conn.cursor()

                # APLICAÇÃO -> VIEW -> BANCO
                cur.execute("""
                    SELECT
                        id_reserva,
                        hospede,
                        check_in,
                        check_out,
                        valor_diaria,
                        status
                    FROM vw_reservas
                    ORDER BY id_reserva
                """)

                registros = cur.fetchall()

                for item in tabela.get_children():
                    tabela.delete(item)

                for registro in registros:
                    tabela.insert("", tk.END, values=registro)

                cur.close()
                conn.close()

            except Exception as e:
                messagebox.showerror("Erro", str(e))

        tk.Button(
            self.root, text="Atualizar relatório",
            width=25, command=carregar
        ).pack(pady=8)

        tk.Button(
            self.root, text="Voltar",
            width=20, command=self.criar_interface
        ).pack()

        carregar()


# ==========================================================
# INICIAR SISTEMA
# ==========================================================
if __name__ == "__main__":
    root = tk.Tk()
    app = SistemaHospedagem(root)
    root.mainloop()
